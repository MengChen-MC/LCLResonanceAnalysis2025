%% Nominal values and used to derive p.u. values
Sn = 5000e3;        % Rated power, W
Vn = 690;           % Rated line-to-line RMS voltage, V
Vpn = Vn*sqrt(2/3); % Rated line-to-ground voltage magnitude, V
In = 2/3*Sn/Vpn;    % Rated current magnitude, A
fn = 50;            % Rated frequency, Hz
wn = 2*pi*fn;       % Rated angular frequency, rad/s
Zb = Vn^2/Sn;       % Base impedance, Ohm
Cb = 1/(wn*Zb);     % Base capacitance, F
Lb = Zb/wn;         % Base inductance, H
Vdcn = 1200;        % Rated DC voltage, V
Idcn = Sn/Vdcn;     % Rated DC current, A
Zdcb = Vdcn/Idcn;   % Base DC impedance, Ohm
Cdcb = 1/(wn*Zdcb); % Base DC capacitor, F

%% Simulation parameters
fsw = 5e3;   % Switching frequency, Hz
Tsw = 1/fsw; % Switching period, s
fs = fsw*2;  % Sampling frequency, Hz
Ts = 1/fs;   % Sampling time, s
fc = fs*20;  % calculation frequency of simulink, Hz

%% System parameters

% LCL filter is designed such that the resonace frequency is 1/5*fsw, C provides 5% reactive power, and minimum Lf + Lg requring Lf/Lg = 1
Cf_phy = 1600e-6;   % LCL capacitance, F
Lf_phy = 3.2e-5; % LCL inverter-side inductance, H
Lg_phy = 3.2e-5 + 2.8e-5 + 12.8e-5; % LCL grid-side inductance + line inductance, H
Rg_phy = Lg_phy*wn/6; % line resistance, suppose X/R = 6, Ohm
wres = 1/(2*pi)*sqrt((Lf_phy+Lg_phy)/Lf_phy/Lg_phy/Cf_phy); % resonance frequency, Hz

% power grid
Vg_phy = Vn;    % grid voltage magnitude, V
fg_phy = fn;    % grid frequency, Hz
wg_phy = wn;    % grid angular frequency, rad/s

% DC link
Cdc_phy = 0.3; % DC capacitor, F

% virtual resistor
Rv2 = 0; % [0, -2, -0.044], [0.003, -5, -0.044], [0.008, -10, -0.044], [0.019, -20, -0.044], [0.029, -30, -0.044]
Rv4 = 100000; % [100000, -2, -0.044], [1100, -5, -0.044], [410, -10, -0.44], [182, -20, -0.44], [117, -30, -0.044]
Rv5 = 0; % [0, -2, -0.044], [0.011, -5, -0.079], [0.029, -10, -0.14], [0.065, -20, -0.24], [0.101, -30, -0.34]
kd = 3.3e-6;
Td = 8e-5;

% transform to p.u. values
Cf = Cf_phy/Cb;
Lf = Lf_phy/Lb;
Lg = Lg_phy/Lb;
Rg = Rg_phy/Zb;
Vg = Vg_phy/Vn;
wg = wg_phy/wn;
Cdc = Cdc_phy/Cdcb;

Xf = Lf;
Xg = Lg;
Xc = Cf;

%% GFM power control
% Droop coefficients are designed such that changes of 100% active and
% reactive power respond to changes of 2% frequency and 10% voltage magnitude, respectively 
dp = 50;   % droop coefficient of active power-frequency loop, p.u.
dq = 10;   % droop coefficient of reactive power-voltage magnitude loop, p.u.
wst = 1;   % set-point value of angular frequency of active power-frequency droop, p.u.
h = 0.5;   % virtual inertia constant, s
Qst = 0;   % set-point values of reactive power of reactive power-voltage droop, p.u.
Vst = 1;   % set-point values of voltage magnitude of reactive power-voltage droop, p.u.
kq = 4;    % integral gain of reactive power-voltage loop, p.u.
eq = 0;    % set-point value of q-axis component of inverter voltage

Tq = 1;
%% DC control 10 Hz
Vdcst = 1; % set-point value of DC voltage, p.u.
kpdc = 3.8; % proportional gain of DC PI controller
kidc = 63.8; % integral gain of DC PI controller kidc = wn*(kpdc - erf*id)^2/2/Cdc

%% Parameters of PMSG-WT
rho = 1.2;        % air density, kg/m3
R = 63;           % wind turbine blade length, m
Copt = 0.44;      % optimal power coefficient
lamopt = 7;       % optimal tip speed ratio
wr = 1.0137;      % wind turbine rotor speed, rad/s

%%
wrfinal = 1.1857;  % set-point step of active power, rad/s
Qstfinal = 0.1;    % set-point step of reactive power, p.u.
Vdcstfinal = 1.05; % set-point step of DC-link voltage, p.u.